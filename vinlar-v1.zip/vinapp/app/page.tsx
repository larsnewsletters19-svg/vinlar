import Link from 'next/link';

const sections = [
  {
    href: '/druvor',
    icon: '🍇',
    title: 'Druvor',
    desc: 'Utforska druvsorter, typiska aromer och stilar.',
    color: 'from-wine-800 to-wine-900',
  },
  {
    href: '/jamfor',
    icon: '⚖️',
    title: 'Jämför',
    desc: 'Ställ druvor och stilar mot varandra.',
    color: 'from-stone-800 to-stone-900',
  },
  {
    href: '/aromhjul',
    icon: '🌸',
    title: 'Aromhjul',
    desc: 'Se druvors aromprofil i ett visuellt hjul.',
    color: 'from-rose-900 to-wine-950',
  },
  {
    href: '/trana',
    icon: '🎯',
    title: 'Träna',
    desc: 'Öva blindprovning med ledtrådsfrågor.',
    color: 'from-amber-900 to-stone-950',
  },
  {
    href: '/lar-dig',
    icon: '🧠',
    title: 'Lär dig känna',
    desc: 'Förstå syra, tannin, kropp och ek.',
    color: 'from-emerald-900 to-stone-950',
  },
];

export default function Home() {
  return (
    <div className="px-4 py-10 max-w-2xl mx-auto">
      <div className="mb-12 text-center">
        <h1 className="font-display text-5xl text-wine-100 mb-3">
          Vin<span className="text-amber-400">Lär</span>
        </h1>
        <p className="text-wine-300 text-lg leading-relaxed max-w-md mx-auto">
          Lär dig känna igen druvsorter, förstå aromer och träna blindprovning — på ett praktiskt och pedagogiskt sätt.
        </p>
      </div>

      <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {sections.map((s) => (
          <li key={s.href}>
            <Link
              href={s.href}
              className={`flex items-start gap-4 p-5 rounded-2xl bg-gradient-to-br ${s.color} border border-wine-800 hover:border-wine-600 transition-all hover:scale-[1.01] active:scale-[0.99] block`}
            >
              <span className="text-3xl mt-0.5">{s.icon}</span>
              <div>
                <div className="font-display text-xl text-wine-50 mb-1">{s.title}</div>
                <div className="text-sm text-wine-300 leading-snug">{s.desc}</div>
              </div>
            </Link>
          </li>
        ))}
      </ul>

      <p className="text-center text-wine-500 text-xs mt-10">
        Version 1.0 · Data lagras lokalt · Ingen inloggning krävs
      </p>
    </div>
  );
}
