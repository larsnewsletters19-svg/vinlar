'use client';

import { useState, useCallback } from 'react';
import questions from '@/data/trainingQuestions.json';
import { TrainingQuestion } from '@/types';

const allQuestions = questions as TrainingQuestion[];

const typeLabels: Record<string, string> = {
  guess_grape: '🍇 Gissa druvan',
  guess_style: '🗺️ Gissa stilen',
  distinguish: '🔍 Skilj dem åt',
  match_aroma: '🌸 Para ihop arom',
};

export default function TranaPage() {
  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [shuffled] = useState(() => [...allQuestions].sort(() => Math.random() - 0.5));
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  const question = shuffled[current];
  const isCorrect = selected === question?.correctAnswer;

  const handleAnswer = (option: string) => {
    if (selected) return;
    setSelected(option);
    if (option === question.correctAnswer) setScore((s) => s + 1);
  };

  const handleNext = useCallback(() => {
    if (current + 1 >= shuffled.length) {
      setFinished(true);
    } else {
      setCurrent((c) => c + 1);
      setSelected(null);
    }
  }, [current, shuffled.length]);

  const restart = () => {
    setCurrent(0);
    setSelected(null);
    setScore(0);
    setFinished(false);
  };

  if (finished) {
    const pct = Math.round((score / shuffled.length) * 100);
    return (
      <div className="px-4 py-16 max-w-xl mx-auto text-center">
        <div className="text-6xl mb-4">{pct >= 80 ? '🥇' : pct >= 60 ? '🥈' : '🎓'}</div>
        <h2 className="font-display text-4xl text-wine-100 mb-3">Klart!</h2>
        <p className="text-wine-300 text-lg mb-2">
          Du fick {score} av {shuffled.length} rätt.
        </p>
        <p className="text-wine-400 text-sm mb-8">
          {pct >= 80 ? 'Utmärkt! Din blindprovning sitter.' : pct >= 60 ? 'Bra jobbat – fortsätt träna.' : 'Bra start – prova igen och se om det sitter bättre.'}
        </p>
        <button
          onClick={restart}
          className="px-6 py-3 bg-wine-600 hover:bg-wine-500 text-white font-medium rounded-xl transition-colors"
        >
          Träna igen
        </button>
      </div>
    );
  }

  return (
    <div className="px-4 py-8 max-w-xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <h1 className="font-display text-3xl text-wine-100">Träna</h1>
        <div className="text-sm text-wine-400">
          {current + 1} / {shuffled.length}
        </div>
      </div>

      {/* Progress */}
      <div className="h-1.5 bg-wine-900 rounded-full mb-8 overflow-hidden">
        <div
          className="h-full bg-wine-600 rounded-full transition-all duration-300"
          style={{ width: `${((current) / shuffled.length) * 100}%` }}
        />
      </div>

      <div className="mb-3">
        <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-wine-900 border border-wine-700 text-wine-400">
          {typeLabels[question.type] || question.type}
        </span>
      </div>

      <div className="bg-wine-900 rounded-2xl p-5 border border-wine-800 mb-6">
        <p className="text-wine-100 leading-relaxed">{question.question}</p>
      </div>

      <ul className="space-y-2 mb-6">
        {question.options.map((option) => {
          let state: 'default' | 'correct' | 'wrong' | 'missed' = 'default';
          if (selected) {
            if (option === question.correctAnswer) state = 'correct';
            else if (option === selected) state = 'wrong';
          }
          return (
            <li key={option}>
              <button
                onClick={() => handleAnswer(option)}
                disabled={!!selected}
                className={`w-full text-left px-4 py-3 rounded-xl border text-sm font-medium transition-all ${
                  state === 'correct'
                    ? 'bg-green-900/50 border-green-600 text-green-300'
                    : state === 'wrong'
                    ? 'bg-red-900/50 border-red-700 text-red-300'
                    : state === 'missed'
                    ? 'bg-green-900/30 border-green-700/50 text-green-400'
                    : selected
                    ? 'bg-wine-900/50 border-wine-800 text-wine-500 cursor-not-allowed'
                    : 'bg-wine-900 border-wine-700 text-wine-200 hover:border-wine-500 hover:text-wine-50 cursor-pointer'
                }`}
              >
                <span className="mr-2">
                  {state === 'correct' ? '✓' : state === 'wrong' ? '✗' : ''}
                </span>
                {option}
              </button>
            </li>
          );
        })}
      </ul>

      {selected && (
        <div className={`rounded-2xl p-5 border mb-6 ${isCorrect ? 'bg-green-900/30 border-green-700/50' : 'bg-red-900/30 border-red-700/50'}`}>
          <p className={`text-sm font-medium mb-1 ${isCorrect ? 'text-green-300' : 'text-red-300'}`}>
            {isCorrect ? '✓ Rätt!' : '✗ Inte riktigt.'}
          </p>
          <p className="text-wine-300 text-sm leading-relaxed">{question.explanation}</p>
        </div>
      )}

      {selected && (
        <button
          onClick={handleNext}
          className="w-full py-3 bg-wine-700 hover:bg-wine-600 text-wine-50 font-medium rounded-xl transition-colors"
        >
          {current + 1 >= shuffled.length ? 'Se resultat' : 'Nästa fråga →'}
        </button>
      )}
    </div>
  );
}
